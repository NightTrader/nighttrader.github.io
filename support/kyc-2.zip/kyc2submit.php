<?php
if(isset($_POST['submit'])) {
    $to = "youremail@gmail.com";
    $from = $_POST['email'];
    $fName = $_POST['fName'];
    $lName = $_POST['lName'];
    $Nationality = $_POST['Nationality'];
    $dobDate = $_POST['dobDate'];
    $dobMonth = $_POST['dobMonth'];
    $dobYear = $_POST['dobYear'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $address = $_POST['address'];
    $address2 = $_POST['address2'];
    $city = $_POST['city'];
    $postcode = $_POST['postcode'];
    $gender = $_POST['gender'];

    $semi_rand = md5(time());
    $mime_boundary = "==Multipart_Boundary_x".$semi_rand."x";

    $headers = "From: $from\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed;\r\n";
    $headers .= " boundary=\"{$mime_boundary}\"";

    $email_message = "--{$mime_boundary}\r\n";
    $email_message .= "Content-Type:text/html; charset=\"UTF-8\"\r\n";
    $email_message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $email_message .= $message . "\r\n";

    foreach ($_FILES['attachments']['tmp_name'] as $key => $tmp_name) {
        $file_name = $_FILES['attachments']['name'][$key];
        $file_size = $_FILES['attachments']['size'][$key];
        $file_type = $_FILES['attachments']['type'][$key];
        $file_tmp = $_FILES['attachments']['tmp_name'][$key];
        $file_content = chunk_split(base64_encode(file_get_contents($file_tmp)));
        $email_message .= "--".$mime_boundary."\r\n";
        $email_message .= "Content-Type: ".$file_type.";\r\n";
        $email_message .= " name=\"{$file_name}\"\r\n";
        $email_message .= "Content-Disposition: attachment;\r\n";
        $email_message .= " filename=\"{$file_name}\"\r\n";
        $email_message .= "Content-Transfer-Encoding: base64\r\n\r\n";
        $email_message .= $file_content . "\r\n";
    }
    $email_message .= "--".$mime_boundary."--";

    if(mail($to, $subject, $email_message, $headers)) {
        echo "Email sent successfully!";
    } else {
        echo "Failed to send email. Please try again.";
    }
}
?>